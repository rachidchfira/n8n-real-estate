# 🚀 Real Estate Automation Hub - Setup Guide

This comprehensive guide will walk you through setting up the complete Real Estate Investment Automation Hub in your n8n instance.

## 📋 Prerequisites Checklist

Before starting, ensure you have:

- [ ] n8n instance (version 1.0+) - cloud or self-hosted
- [ ] Google account with Sheets and Gmail access
- [ ] Slack workspace (optional but recommended)
- [ ] RapidAPI account
- [ ] Real estate data API subscriptions

## 🏗️ Infrastructure Setup

### 1. n8n Installation (if self-hosting)

```bash
# Using Docker (recommended)
docker run -it --rm \
  --name n8n \
  -p 5678:5678 \
  -v ~/.n8n:/home/node/.n8n \
  n8nio/n8n

# Using npm
npm install n8n -g
n8n start
```

### 2. Environment Variables

Create a `.env` file in your n8n directory:

```bash
# Database Configuration
DB_TYPE=postgresdb
DB_POSTGRESDB_HOST=localhost
DB_POSTGRESDB_PORT=5432
DB_POSTGRESDB_DATABASE=n8n
DB_POSTGRESDB_USER=n8n
DB_POSTGRESDB_PASSWORD=your_password

# n8n Configuration
N8N_BASIC_AUTH_ACTIVE=true
N8N_BASIC_AUTH_USER=admin
N8N_BASIC_AUTH_PASSWORD=your_secure_password
N8N_HOST=0.0.0.0
N8N_PORT=5678
N8N_PROTOCOL=https
N8N_EDITOR_BASE_URL=https://your-domain.com/

# Encryption Key
N8N_ENCRYPTION_KEY=your_32_character_encryption_key

# Timezone
GENERIC_TIMEZONE=America/New_York

# Email Configuration
N8N_EMAIL_MODE=smtp
N8N_SMTP_HOST=smtp.gmail.com
N8N_SMTP_PORT=587
N8N_SMTP_USER=your-email@gmail.com
N8N_SMTP_PASS=your-app-password
N8N_SMTP_SENDER=your-email@gmail.com
```

## 🔑 API Keys and Credentials Setup

### 1. RapidAPI Account
1. Visit [RapidAPI.com](https://rapidapi.com)
2. Create account and subscribe to:
   - Realtor.com API
   - Zillow API (if available)
   - Walk Score API
   - Crime Data API
3. Note your RapidAPI key

### 2. Bridge Interactive API
1. Visit [Bridge Interactive](https://bridgedataoutput.com)
2. Sign up for API access
3. Get your API token and access credentials

### 3. RentSpree API
1. Visit [RentSpree](https://rentspree.com)
2. Apply for API access
3. Obtain API key

### 4. Google Services Setup
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create new project or select existing
3. Enable APIs:
   - Google Sheets API
   - Gmail API
   - Google Maps API (optional)
4. Create service account and download credentials
5. Share your Google Sheet with the service account email

### 5. Slack Integration (Optional)
1. Go to [Slack API](https://api.slack.com)
2. Create new app for your workspace
3. Enable incoming webhooks
4. Create webhook URLs for channels:
   - #sales-alerts
   - #deal-alerts
   - #executive-reports

## 📊 Google Sheets Configuration

### 1. Create Master Spreadsheet

Create a new Google Sheets document with the following sheets:

#### Sheet 1: Market Intelligence (gid=0)
Columns:
```
analysis_id | timestamp | location | property_type | price_range | market_score | 
signal | confidence | economic_score | real_estate_score | demographic_score | 
quality_of_life_score | crime_score | school_score | recommendation | notes
```

#### Sheet 2: Property Heatmap (gid=1)
Columns:
```
heatmap_id | timestamp | location | total_properties | avg_price | avg_roi_score | 
high_roi_count | opportunity_zones | investment_grade | color_code | coordinates | 
report_file
```

#### Sheet 3: Deal Hunter (gid=2)
Columns:
```
search_id | timestamp | location | property_type | total_found | foreclosures | 
expired_listings | fsbo_properties | motivated_sellers | auction_properties | 
best_deal_score | confidence | recommendations
```

#### Sheet 4: ROI Projections (gid=3)
Columns:
```
projection_id | timestamp | address | purchase_price | down_payment | 
monthly_cashflow | annual_roi | ten_year_roi | break_even_months | 
risk_score | recommendation | report_file
```

#### Sheet 5: Deal Alerts (gid=4)
Columns:
```
alert_id | timestamp | property_address | alert_type | price_change | 
market_value | deal_score | urgency | recommendation | sent_notifications
```

#### Sheet 6: Property Valuations (gid=5)
Columns:
```
valuation_id | timestamp | address | bedrooms | bathrooms | sqft | 
estimated_value | price_per_sqft | confidence | rent_estimate | value_min | 
value_max | market_trend | methods_used | report_file
```

#### Sheet 7: Lead Management (gid=6)
Columns:
```
lead_id | timestamp | name | email | phone | property_address | property_type | 
budget | timeline | motivation | source | lead_score | lead_quality | priority | 
status | next_follow_up | recommended_action | tags | scoring_factors | notes
```

#### Sheet 8: Follow-up Tasks (gid=7)
Columns:
```
task_id | lead_id | lead_name | lead_phone | lead_email | action | message | 
scheduled_for | status | priority | lead_quality | created_at | completed_at | notes
```

#### Sheet 9: Weekly Reports (gid=8)
Columns:
```
report_id | generated_at | start_date | end_date | markets_analyzed | deals_found | 
leads_generated | properties_valuated | opportunity_score | market_sentiment | 
deal_quality | lead_quality | hot_leads | high_value_deals | hot_markets | 
avg_market_score | avg_deal_score | avg_lead_score | report_file
```

### 2. Get Sheet ID and GIDs
1. Open your Google Sheet
2. Copy the ID from the URL: `https://docs.google.com/spreadsheets/d/YOUR_SHEET_ID/edit`
3. Note the gid numbers for each sheet (visible in URL when selecting sheets)

## 🔄 Workflow Import and Configuration

### 1. Import Workflows

1. Download all JSON files from the `workflows/` directory
2. In n8n, go to "Workflows" → "Import"
3. Import each workflow file:
   - `01_market_intelligence_engine.json`
   - `02_property_heatmap_generator.json`
   - `03_off_market_deal_hunter.json`
   - `04_roi_projection_simulator.json`
   - `05_deal_alert_system.json`
   - `06_property_valuation_engine.json`
   - `07_lead_management_system.json`
   - `08_automated_report_generator.json`

### 2. Global Configuration

In each workflow, update these placeholders:

```javascript
// API Keys
YOUR_RAPIDAPI_KEY → your_rapidapi_key
YOUR_BRIDGE_API_TOKEN → your_bridge_token
YOUR_RENTSPREE_API_KEY → your_rentspree_key

// Google Sheets
YOUR_GOOGLE_SHEET_ID → your_google_sheet_id

// Email Addresses
sales-team@yourcompany.com → your_sales_email
executives@yourcompany.com → your_executive_email

// Slack Channels (if using)
C1234567890 → your_channel_id
```

### 3. Credential Setup in n8n

#### Google Sheets Credentials
1. Go to "Settings" → "Credentials"
2. Add "Google Service Account" credential
3. Upload your service account JSON file
4. Test connection

#### Gmail Credentials
1. Add "Gmail OAuth2" credential
2. Follow OAuth flow to authenticate
3. Grant necessary permissions

#### Slack Credentials (if using)
1. Add "Slack" credential
2. Enter webhook URLs for each channel

## 🧪 Testing and Validation

### 1. Test Individual Workflows

#### Market Intelligence Engine
```bash
curl -X POST "http://localhost:5678/webhook/market-intelligence" \
  -H "Content-Type: application/json" \
  -d '{
    "location": "Austin, TX",
    "propertyType": "single_family",
    "priceRange": "300000-800000"
  }'
```

#### Property Valuation Engine
```bash
curl -X POST "http://localhost:5678/webhook/property-valuation" \
  -H "Content-Type: application/json" \
  -d '{
    "address": "123 Main St, Austin, TX",
    "bedrooms": 3,
    "bathrooms": 2,
    "sqft": 1800,
    "yearBuilt": 2010
  }'
```

#### Lead Management System
```bash
curl -X POST "http://localhost:5678/webhook/new-lead" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "(555) 123-4567",
    "budget": "500000",
    "timeline": "30 days",
    "motivation": "investment property"
  }'
```

### 2. Verification Checklist

- [ ] Webhooks are accessible and responding
- [ ] Data is being written to Google Sheets
- [ ] Email notifications are being sent
- [ ] Slack notifications are working (if configured)
- [ ] API calls are successful (check logs)
- [ ] Reports are generated correctly

## 🔧 Customization Options

### 1. Scoring Algorithm Tuning

#### Market Intelligence Scoring Weights
```javascript
// In Market Intelligence Engine Code Node
const weights = {
  economic: 0.25,        // Economic indicators weight
  realEstate: 0.30,      // Real estate metrics weight  
  demographic: 0.15,     // Population/demographic weight
  qualityOfLife: 0.15,   // Schools, crime, walkability weight
  sentiment: 0.15        // Market sentiment weight
};
```

#### Lead Scoring Adjustments
```javascript
// In Lead Scoring Engine Code Node
const scoringFactors = {
  budget: 30,            // Max points for budget
  timeline: 25,          // Max points for urgency
  motivation: 20,        // Max points for motivation
  source: 15,            // Max points for lead source
  contact: 10            // Max points for contact completeness
};
```

### 2. Notification Thresholds

#### Hot Lead Alert Threshold
```javascript
// Modify in Lead Management System
if (leadScore >= 70) {  // Change this threshold
  leadQuality = 'Hot';
  // Triggers immediate alerts
}
```

#### Deal Alert Sensitivity
```javascript
// Modify in Deal Alert System
const alertThresholds = {
  priceDropPercent: 5,   // Alert on 5%+ price drops
  dealScore: 75,         // Alert on deals scoring 75+
  daysOnMarket: 30       // Alert on properties 30+ days
};
```

### 3. Report Scheduling

#### Change Report Frequency
```javascript
// In Automated Report Generator cron trigger
"0 8 * * 1"     // Weekly on Mondays at 8 AM
"0 8 * * *"     // Daily at 8 AM
"0 8 1 * *"     // Monthly on 1st at 8 AM
```

### 4. Data Source Configuration

#### Add New APIs
```javascript
// Example: Adding Zillow API
const zillowResponse = await fetch('https://api.zillow.com/...', {
  headers: {
    'X-RapidAPI-Key': 'YOUR_KEY',
    'X-RapidAPI-Host': 'zillow.p.rapidapi.com'
  }
});
```

## 🚨 Error Handling and Monitoring

### 1. Common Error Scenarios

#### API Rate Limiting
```javascript
// Add delays between API calls
await new Promise(resolve => setTimeout(resolve, 1000));
```

#### Missing Data Handling
```javascript
// Provide fallback values
const price = propertyData.price || marketData.avgPrice || 0;
```

#### Webhook Timeouts
- Keep workflows under 30 seconds execution time
- Use async processing for long-running tasks
- Implement proper error responses

### 2. Monitoring Setup

#### Workflow Health Checks
1. Set up monitoring workflows that test key endpoints
2. Create alerts for failed executions
3. Monitor Google Sheets for data gaps

#### Performance Monitoring
1. Track execution times
2. Monitor API usage and costs
3. Set up resource alerts

## 🔐 Security Best Practices

### 1. API Key Management
- Store all API keys in n8n credentials, never in workflows
- Rotate API keys regularly
- Use environment variables for sensitive data

### 2. Access Control
- Enable n8n basic authentication
- Use HTTPS in production
- Restrict webhook access with authentication tokens

### 3. Data Privacy
- Implement data retention policies
- Secure Google Sheets access
- Regular security audits

## 📈 Scaling Considerations

### 1. Performance Optimization
- Use parallel execution where possible
- Implement caching for frequently accessed data
- Optimize database queries

### 2. High Volume Processing
- Set up workflow queues
- Implement batch processing
- Use database storage instead of Google Sheets for high volume

### 3. Multi-tenant Setup
- Separate workflows by organization
- Use environment variables for tenant-specific config
- Implement proper data isolation

## 🆘 Troubleshooting Guide

### Common Issues and Solutions

#### "Webhook not found" Error
- Check webhook paths are correct
- Ensure workflows are active
- Verify n8n is accessible

#### "Authentication failed" Error
- Verify API keys are correct
- Check credential configuration
- Test API endpoints manually

#### "Google Sheets permission denied"
- Share sheet with service account email
- Verify OAuth scopes
- Check credential configuration

#### "Workflow timeout" Error
- Reduce API calls per execution
- Implement pagination
- Split complex workflows

#### "Missing data in reports"
- Check all data source workflows are running
- Verify Google Sheets write permissions
- Check for API failures in logs

### Getting Help

1. **Check Logs**: n8n execution logs provide detailed error information
2. **Test Components**: Test individual nodes to isolate issues
3. **Community Support**: n8n community forum and Discord
4. **Professional Support**: Contact for enterprise support options

## 🎯 Next Steps

After successful setup:

1. **Data Collection**: Let workflows run for a week to gather baseline data
2. **Threshold Tuning**: Adjust scoring and alert thresholds based on your market
3. **Custom Integrations**: Add your preferred CRM or other tools
4. **Team Training**: Train your team on using the system
5. **Monitoring Setup**: Implement ongoing monitoring and maintenance procedures

---

**Congratulations! Your Real Estate Automation Hub is now ready to revolutionize your investment workflow.**

For ongoing support and updates, refer to the main README.md and join our community channels.
